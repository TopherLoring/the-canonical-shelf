# Canonical Shelf — curriculum review and original-scope audit

## Review outcome

The revised course preserves the original Bible-literacy system while expanding the guided Christianity curriculum from 23 to **70 lessons across 16 units**. Every unit now contains **4–5 lessons**. The original 23 lesson IDs are retained, so existing notes and lesson milestones remain compatible. The expansion adds 47 new lesson IDs instead of replacing earlier content.

The guided course and the original book-skill curriculum are intentionally separate progress dimensions. A user can understand theological material without yet having memorized canonical order, and can know book order without yet understanding context or theology. The interface therefore exposes both rather than treating either as a proxy for the other.

## Original intended learning — preserved

The original design was a structured Bible-literacy system with seven tracks totaling 69 steps:

| Original mode | Steps | Required capability | Status in revised course |
|---|---:|---|---|
| **0 · The Story** | 10 | Follow the arc in ten beats and identify the books carrying each stage | Preserved; surfaced as a core Bible skill lab and linked from narrative units |
| **1 · Order** | 17 | Learn group order, then each testament, then all 66 books | Preserved; linked from orientation/covenant/project work |
| **2 · Groups** | 12 | Learn nine shelf groups and how literary forms should be read | Preserved; Unit 2 explicitly distinguishes shelf group from literary genre |
| **3 · Chronology** | 7 | Distinguish shelf order from historical/narrated time | Preserved; disputed dates/composition remain teaching models rather than absolute claims |
| **4 · Content** | 8 | Recognize summaries, major casts, openings, authorship information, and audiences | Preserved and connected to Gospel/letter/project units |
| **5 · Themes** | 7 | Trace fourteen threads across books | Preserved; expanded with fourteen paired-passage investigations |
| **6 · Verses** | 8 | Identify themes, speaker, recipient, and reconstruct verse wording | Preserved and connected to interpretation units |

**Total original skill steps: 69.** The original book drills and End-to-End practice remain available.

## Revised 16-unit structure

| Unit | Lessons | Coverage |
|---|---:|---|
| 1. Orientation | 5 | central proclamation; Bible as library; larger story; context detective; neighbor/mercy |
| 2. Reading Scripture | 5 | genre; audience/context; translation/textual criticism; application; shelf/timeline/seven Bible skills |
| 3. Creation and humanity | 4 | integrated creation overview; garden/freedom; sin/mortality/tree of life; creation care |
| 4. Covenant and liberation | 4 | integrated covenant overview; Abraham/blessing; Exodus/liberation; Torah/neighbor responsibilities |
| 5. Land, kingdom, and exile | 5 | integrated overview; Judges/violence; kingship/accountability; exile/lament; return/rebuilding |
| 6. Prayer and wisdom | 5 | integrated overview; Psalms/lament; Proverbs/discernment; Job/suffering; Ecclesiastes/Song |
| 7. Prophets and justice | 4 | integrated overview; Amos/worship and justice; Micah/mercy; Jeremiah/exilic hope |
| 8. Jesus in his Jewish world | 4 | integrated overview; kingdom/discipleship; parables/welcome; comparing Gospels |
| 9. Cross and resurrection | 4 | integrated overview; atonement images; receiving grace; repentance/repair |
| 10. Early Church | 4 | integrated overview; Acts 15/discernment; body/belonging; James/favoritism |
| 11. God and Christian doctrine | 5 | integrated overview; Trinity; incarnation; Spirit; providence/free response |
| 12. Practicing Christianity | 4 | integrated overview; baptism; Communion/open table; prayer/formation |
| 13. Christian traditions | 4 | integrated overview; creeds; authority/ecumenism; seven-denomination comparison |
| 14. Difficult questions | 5 | integrated overview; difficult ethical texts; LGBTQ affirmation; Jewish roots/religious difference; suffering/miracles/spiritual discernment |
| 15. Hope and new creation | 4 | integrated overview; bodily resurrection; judgment/competing interpretations; apocalyptic hope |
| 16. Independent study | 4 | integrated overview; whole-book observation; argument/theme tracing; application/revision |

## Improvements retained from Units 1–2

- **Translation mechanics:** 1 John 5:6–8 supplies a concrete manuscript-variant workshop, distinguishing textual evidence from English rendering and from later doctrinal conclusions.
- **Genre comparison:** learners compare poetry, narrative, legal instruction, and apocalyptic symbolism rather than merely memorizing genre definitions.
- **Corinthian context:** patronage/status is introduced as a useful historical lens while explicit textual evidence—hunger, inequality, humiliation—is kept distinct from reconstruction of individual motives.
- **Argument maps:** learners connect observations to an interpretation and then to a proportionate application, leaving unsupported leaps disconnected.

## Engagement and learning-process review

### Strengths after expansion

**Layering.** Each new lesson supplies a primary passage, substantive explanation, a simpler explanation, three key terms, deeper inquiry, optional reflection, and a model reflection. A novice can stop at the simple layer while a more advanced learner can continue into interpretive boundaries.

**Active reasoning.** New lessons use evidence selection and multi-stage scenarios for first encounters, followed by argument mapping and conceptual reconstruction on return. Existing sequencing, matching, reader/search, and legacy game engines remain part of the ecosystem.

**Transfer rather than assent.** Correct answers concern what a text supports, what an interpretation claims, or how an application follows. A learner is never required to disclose or perform personal belief to earn a milestone.

**Spaced return.** The existing 1/3/7/14-day return schedule remains. New lesson IDs extend the same state model without invalidating existing progress.

**Navigation competence.** Unit 2 explicitly explains the difference among shelf grouping, literary genre, narrated setting, and composition. The seven original skill tracks are presented as course requirements rather than hidden legacy features.

**Cross-book synthesis.** The independent-study unit contains fourteen theme comparisons: covenant; exile/return; kingdom/king; sacrifice/atonement; wilderness/testing; remnant; temple/presence; judgment; mercy/steadfast love; redemption/rescue; wisdom; faithfulness under pressure; worship/lament; mission outward.

## Original-information preservation check

No original mode was removed. The revised course still teaches the ten-beat Bible story; all 66 books and their canonical order; nine shelf groups and genre-reading approaches; chronology versus shelf order; book summaries, characters, openings, authorship and audiences; fourteen cross-book themes; and verse theme, speaker, recipient, and reconstruction.

The newer theology curriculum adds rather than substitutes: contextual interpretation, textual criticism, Jewish context, Christian doctrine, practices, denominational comparison, ethical questions, inclusive theology, and independent-study method.

## Remaining gaps and recommended next improvements

### High priority

1. **Late-course challenge difficulty.** New lessons intentionally use a consistent novice scaffold: evidence board → scenario → return argument map → concept reconstruction. This is learnable but can become predictable. After novice testing, add advanced transfer missions with multiple plausible readings, conflicting evidence, and fewer structural hints.
2. **66-book scholarly audit.** Existing book profiles and chronology are useful teaching models, but this expansion is not a source-by-source scholarly review of every authorship/date/audience claim. Add confidence labels and sources for disputed attributions and ranges.
3. **Human feedback on capstone work.** Automated missions can validate method structure but cannot certify the quality of a learner's independent exegesis. Add a facilitator/peer rubric for claim, evidence, counterevidence, context, and application.

### Medium priority

4. **Second Temple Judaism and canon development.** The Jewish setting and differing Christian canons are introduced, but a dedicated historical bridge between the Testaments would materially improve Gospel literacy.
5. **Denominational depth.** The seven requested traditions are represented and official sources are attached; a dedicated comparison matrix for authority, baptism, Communion, polity, inclusion, and worship would improve retention.
6. **Difficult-text electives.** Conquest, slavery, women, sexuality, suffering, judgment, miracles, and spiritual evil are addressed, but each could support a deeper optional passage study without burdening the core novice sequence.
7. **Visual orientation.** Timelines, relationship maps, geographic maps, and book-to-era visualizations would reduce cognitive load for beginners. They should supplement, not replace, accessible text.
8. **Glossary/navigation index.** Vocabulary exists lesson by lesson; a cross-course searchable glossary would improve reference use.

### Validation still needed

9. **Target-learner testing.** Structural and interaction tests do not prove that adults with little Bible knowledge find the sequence clear, engaging, or memorable. Pilot the full path with novice adults and record where they hesitate, abandon, or form recurring misconceptions.
10. **Assistive technology and cross-browser testing.** Keyboard/touch design exists, but a complete screen-reader and device/browser matrix should be performed before calling the interface fully accessible.

## Release assessment

The revised curriculum satisfies the structural requirement of 4–5 lessons in every unit and preserves the full original Bible-literacy plan. It is broad enough to function as an adult introduction to the Bible and Christianity rather than merely a set of memory drills. The strongest next improvements are not more core topics; they are harder transfer practice, better source transparency, visual orientation, and human feedback so breadth becomes durable competence rather than content exposure.
