(() => {
  'use strict';
  const D=window.FOUNDATIONS_DATA, F=window.Foundations;
  if(!D || !F || !Array.isArray(D.skillTracks)) throw Error('Expansion metadata missing');

  if(F?.exportState && F?.importState){
    try { F.importState(F.exportState()); } catch(e) { console.error('Progress migration failed',e); }
  }

  function skillDone(id){
    try { return typeof modeSteps==='function' && typeof stepDone==='function' ? modeSteps(id).filter(x=>stepDone(x.id)).length : 0; }
    catch { return 0; }
  }
  function labs(ids=D.skillTracks.map(t=>t.id)){
    const wrap=document.createElement('section');wrap.className='fd-skill-labs';wrap.dataset.expansion='skills';
    wrap.innerHTML=`<h3>Core Bible skill labs</h3><p>The original seven learning tracks remain part of the course. Their progress is separate from guided lesson milestones.</p><div class="fd-grid">${D.skillTracks.filter(t=>ids.includes(t.id)).map(t=>`<article class="fd-card"><h4>${t.title}</h4><p>${t.purpose}</p><p>${skillDone(t.id)}/${t.steps} skill steps complete</p><button type="button" data-skill-track="${t.id}">Open ${t.title} lab</button></article>`).join('')}</div>`;
    return wrap;
  }
  function decorate(){
    for(const panelId of ['panel-learn','panel-play']){
      const panel=document.getElementById(panelId),fd=panel?.querySelector('.fd');if(!fd)continue;
      const h2=fd.querySelector('h2')?.textContent?.trim()||'';
      if((h2==='A guided beginning'||h2==='Practice understanding')&&!fd.querySelector('[data-expansion="home"]')){
        const marker=document.createElement('section');marker.dataset.expansion='home';marker.className='fd-course-progress';
        const total=D.skillTracks.reduce((n,t)=>n+t.steps,0),done=D.skillTracks.reduce((n,t)=>n+skillDone(t.id),0);
        const next=D.lessons.find(l=>{try{return !F.exportState().lessons[l.id]?.passed}catch{return true}})||D.lessons[0];
        marker.innerHTML=`<p><strong>${done}/${total} core Bible skill steps complete.</strong> Complete both guided lessons and the seven skill tracks for full coverage of the original learning plan.</p><button type="button" data-continue-lesson="${next.id}">Continue: ${next.title}</button><p><a href="docs/course-review.md">Review original-scope coverage and remaining improvements</a></p>`;
        const filter=fd.querySelector('.fd-unit-filter');(filter||fd.firstElementChild).after(marker,labs());
      } else if(h2 && !['A guided beginning','Practice understanding','A guide to Christian belief'].includes(h2) && !fd.querySelector('[data-expansion="lesson-skills"]')){
        const lesson=D.lessons.find(l=>l.title===h2);if(lesson){
          const box=document.createElement('details');box.dataset.expansion='lesson-skills';box.innerHTML='<summary>Practice related Bible skills</summary>';
          box.append(labs(lesson.tracks));
          fd.append(box);
          if(lesson.comparisons){const comp=document.createElement('details');comp.dataset.expansion='themes';comp.innerHTML=`<summary>Fourteen theme investigations</summary><p>Choose one for the independent project; revisit the rest as continuing study.</p>${lesson.comparisons.map(c=>`<h4>${c.title}</h4><p><strong>${c.reading}</strong></p><p>${c.prompt}</p>`).join('')}`;fd.append(comp);}
        }
      }
    }
  }
  document.addEventListener('click',e=>{
    const track=e.target.closest?.('[data-skill-track]');
    if(track){e.preventDefault();try{S.legacyLearn=true;S.learnMode=track.dataset.skillTrack;setTab('learn');if(typeof scrollToWork==='function')scrollToWork();}catch(err){console.error(err);}return;}
    const cont=e.target.closest?.('[data-continue-lesson]');
    if(cont){e.preventDefault();try{F.open('panel-learn');queueMicrotask(()=>{const id=cont.dataset.continueLesson;document.querySelector(`#panel-learn [data-fd="lesson"][data-id="${id}"]`)?.click();});}catch(err){console.error(err);}}
  });
  let scheduled=false;
  const observer=new MutationObserver(()=>{if(scheduled)return;scheduled=true;queueMicrotask(()=>{scheduled=false;decorate();});});
  for(const id of ['panel-learn','panel-play']){const el=document.getElementById(id);if(el)observer.observe(el,{childList:true,subtree:true});}
  try {
    if(typeof S!=='undefined' && S.tab==='play') F.open('panel-play'); else F.open('panel-learn');
  } catch { F?.open?.('panel-learn'); }
  decorate();
  delete window.CANON_EXPAND;
})();
